package com.example.tictactoe;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.app.AlertDialog;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Observable;
import java.util.Observer;

public class MainActivity extends AppCompatActivity {
    public Button[][] buttons = new Button[3][3];
    public String player1Name;
    public String player2Name;
    public Context context;
    private Controller C = new Controller();

    /* INSP: https://codinginflow.com/tutorials/android/tic-tac-toe/part-4-configuration-changes-reset-game*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = getApplicationContext();
        setContentView(R.layout.activity_main);
        setPlayer1Name();
        setPlayer2Name();
        //Lägger till lyssnare på spelplanen
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                final String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(new View.OnClickListener(){
                    public void onClick(View view) {
                        C.makeMove(view, buttons, player1Name, player2Name, context);
                    }
                });
            }
        }
        //Lyssnare för Reset
        Button buttonReset = findViewById(R.id.button_reset);
        buttonReset.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                C.restart(buttons);
                Toast.makeText(context, "Game reset!", Toast.LENGTH_SHORT).show();
            }
        });
    }
    // INSPO: https://stacktips.com/tutorials/android/android-input-dialog-example
    public void setPlayer1Name() {
        LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
        View promptView = layoutInflater.inflate(R.layout.popup_window, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
        alertDialogBuilder.setView(promptView);
        final EditText editText = (EditText) promptView.findViewById(R.id.edittext);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        player1Name = editText.getText().toString();
                    }
                });
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
       }
        public void setPlayer2Name() {

            LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
            View promptView = layoutInflater.inflate(R.layout.popup_window, null);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
            alertDialogBuilder.setView(promptView);

            final EditText editText = (EditText) promptView.findViewById(R.id.edittext);

            alertDialogBuilder.setCancelable(false)
                    .setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            player2Name = editText.getText().toString();
                        }
                    });


            AlertDialog alert = alertDialogBuilder.create();
            alert.show();
        }


}