package com.example.tictactoe;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Controller {
    private boolean playerXTurn = true;
    private int turnCount = 0;
    Model M = new Model();

    public void makeMove(View v, Button buttons[][], String P1, String P2, Context c) {
        if (!((Button) v).getText().toString().equals("")) { //Om en knapp har en text
            return;
        }
        if (playerXTurn) { // Om det är Xs tur
            ((Button) v).setText("X"); //Sätter texten på knappen till X
        } else {
            ((Button) v).setText("O");
        }

        turnCount++; //Räknar upp turnCounts med 1

        if (M.checkForWinner(buttons)) { //Om checkForWinner är true, alltså någon har vunnit.
            if (playerXTurn) { //Om det var X tur
                playerXWins(P2, c); //Kallar på funktionen för att skriva ut att X har funnit, skickar med namnet och Context
                restart(buttons); //Start om spelet och skickar med knapparna
            } else {
                playerOWins(P1, c);
                restart(buttons);
            }
        } else if (turnCount == 9) { //om det gått 9 rundor
            gameIsDrawn(c); //Skickar med context till funktionen som skriver ut att det är oavgjort
            restart(buttons);
        } else {
            playerXTurn = !playerXTurn; //Om det är X tur ändras det till Os tur och tvärtom
        }
    }

    public void playerXWins(String P2, Context c) { //Om X vinner
        Toast.makeText(c, P2 + " wins!", Toast.LENGTH_SHORT).show();
    }

    public void playerOWins(String P1, Context c) { //Om O vinner
        Toast.makeText(c, P1 + " wins!", Toast.LENGTH_SHORT).show();
    }

    public void gameIsDrawn(Context c)
    { //Om ingen vinner
        Toast.makeText(c, "Draw!", Toast.LENGTH_SHORT).show();
    }

    public void restart(Button buttons[][]){ //start om spelet

        for (int i = 0; i < 3; i++) { //Sätter alla knappar i spelet till ""
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }
        turnCount = 0; //Sätter tillbaka variblerna som dom var vid start
        playerXTurn = true;

    }
}
